var db = require('../db');
var shortid = require('shortid');

module.exports.index = function(req, res){
	var page = parseInt(req.query.page) || 1;
	var perPage = 8;

	var start = ( page - 1 ) * perPage;
	var end = page * perPage;

	res.render('item/index', {
		items:db.get('items').value().slice(start, end)
	})
}

module.exports.search = function(req, res){
	var q = req.query.q;
	var searchIem = db.get('items').value().filter(function(item){
		return item.name.toLowerCase().indexOf(q.toLowerCase()) !==-1;
	})
	res.render('item/index',{
		items:searchIem
	})
}
module.exports.create = function(req, res){
	res.render('item/create/index')
}
module.exports.postCreate = function(req, res){
	req.body.id = shortid.generate();

	req.body.avatar = req.file.path.split('/').slice(1).join('/');

	db.get('items').push(req.body).write();
	res.redirect('/item');	
}
module.exports.id =  function (req, res){
	var id = req.params.id;
	var item = db.get('items').find({id :id}).value();
	res.render('item/view',{
		item:item
	})
}

module.exports.product =  function(req, res){
	var page = parseInt(req.query.page) || 1;
	var perPage = 8;

	var start = (page - 1) * perPage;
	var end = page * perPage;
	res.render('item/product/index', {
		product:db.get('product').value().slice(start, end)
	})
}
